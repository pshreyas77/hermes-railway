---
name: hermes-messaging-gateway
description: "Set up and troubleshoot Hermes Agent messaging gateways (Telegram, Discord, Slack, etc.) for remote access to your agent and tools."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, gateway, telegram, discord, messaging, remote-access, setup]
    homepage: https://hermes-agent.nousresearch.com/docs/user-guide/messaging/
    related_skills: [hermes-agent]
---

# Hermes Messaging Gateway Setup

Class-level skill for configuring Hermes Agent's multi-platform messaging gateway. Covers Telegram, Discord, Slack, and other adapters — from bot creation through config, allowlists, and common pitfalls.

## Scope

- Bot/account creation on each platform
- Hermes `config.yaml` and `.env` configuration
- Gateway startup, restart, and verification
- Allowlist / admin configuration
- Troubleshooting: token masking, duplicate config sections, restart loops

## Telegram Quickstart (Reference)

### 1. Create Bot
- Message `@BotFather` → `/newbot` → name + username (must end in `bot`)
- **Save the token** (format: `123456789:ABC-DEF...`)

### 2. Get Your Chat ID
- Message your new bot anything (e.g., `/start`)
- Message `@userinfobot` or `@getmyid_bot` → copy your numeric **User ID** (e.g., `8336840601`)

### 3. Configure Hermes

**Option A: `.env` (simplest, recommended)**
```bash
echo 'TELEGRAM_BOT_TOKEN="123456789:ABC-DEF..."' >> ~/.hermes/.env
echo 'TELEGRAM_CHAT_ID="8336840601"' >> ~/.hermes/.env
echo 'TELEGRAM_ALLOWED_USERS="8336840601"' >> ~/.hermes/.env
```

**Option B: `config.yaml` (explicit)**
```yaml
platforms:
  telegram:
    enabled: true
    extra:
      bot_token: "123456789:ABC-DEF..."   # QUOTED, not masked
      chat_id: "8336840601"
      admin_chat_ids: '["8336840601"]'
      dm_policy: open
```

### 4. Start Gateway
```bash
hermes gateway run          # foreground (logs visible)
# or
hermes gateway install      # systemd service (Linux/WSL)
hermes gateway start
```

### 5. Verify
In Telegram, message your bot:
```
/platforms
```
Should show `telegram: connected`.

---

## Common Pitfalls & Fixes

| Symptom | Cause | Fix |
|---------|-------|-----|
| `No bot token configured` | Token is `***` (masked) in config.yaml | Edit config.yaml directly (Python/yaml), not `hermes config set` |
| `hermes config set` fails for `platforms.telegram.extra.bot_token` | Dotted key treated as env var name (invalid) | Use `.env` or edit YAML directly |
| Gateway won't restart from inside gateway | SIGTERM propagates to child shell | Stop with `Ctrl+C` in gateway terminal, then rerun |
| Two `platforms:` sections in config.yaml | Legacy + new config merged | Fix **both** occurrences (search for `bot_token:`) |
| "Unknown sender" / commands ignored | No allowlist configured | Set `TELEGRAM_ALLOWED_USERS=your_id` in `.env` or `admin_chat_ids` in config |
| Webhook port not reachable | Behind NAT/firewall | Use polling mode (default) or `cloudflared tunnel --url http://localhost:8644` |
| `.env` not read on Windows | PowerShell `echo`/`>>` writes UTF-16 (BOM), Hermes expects UTF-8 | Write with Python: `python -c "open('.env','w',encoding='utf-8').write(...)"` or use bash |
| Token shows as `123456:***` in config.yaml | `hermes config set` masks values containing `:` in YAML output | Never use `hermes config set` for bot tokens; edit YAML directly |
| Connection retries but fails silently | `dm_policy: restrictive` (default) + no allowlist | Set `dm_policy: open` OR `TELEGRAM_ALLOWED_USERS="your_id"` in .env |
| `hermes gateway restart` blocked | Running inside gateway process | Use **separate terminal window** for gateway commands |

---

## Config Editing Patterns

### Safe YAML Edit (Python)
```python
import yaml
with open('~/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
cfg['platforms']['telegram']['extra']['bot_token'] = 'REAL_TOKEN_HERE'
with open('~/.hermes/config.yaml', 'w') as f:
    yaml.dump(cfg, f)
```

### Fix Masked Token in Place
```bash
python3 -c "
import re
with open('~/.hermes/config.yaml') as f: c = f.read()
c = re.sub(r'bot_token: \d+:\*\*\*', 'bot_token: \"YOUR_REAL_TOKEN\"', c)
with open('~/.hermes/config.yaml', 'w') as f: f.write(c)
"
```

---

## Discord / Slack / Others

Same pattern: create app/bot → get credentials → add to `.env` or `config.yaml` under `platforms.<name>` → `hermes gateway run`.

See [Hermes Messaging Docs](https://hermes-agent.nousresearch.com/docs/user-guide/messaging/) for platform-specific fields.

---

## Verification Checklist

- [ ] Bot responds to `/platforms` with `telegram: connected`
- [ ] `/tools` shows enabled toolsets
- [ ] Vault query works: `/search "term" in wiki`
- [ ] Subagent delegation works: `delegate researcher to "topic"`
- [ ] Cron job delivery works: `hermes cron create "0 9 * * *" --prompt "Daily summary" --deliver telegram`

---

## References

- `references/telegram-setup-guide.md` — Full walkthrough with screenshots
- `references/troubleshooting.md` — Error messages and fixes