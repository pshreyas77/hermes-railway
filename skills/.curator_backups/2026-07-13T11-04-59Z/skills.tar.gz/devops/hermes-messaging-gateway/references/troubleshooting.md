# Hermes Gateway Troubleshooting — Real Session Notes

These are actual errors encountered and fixes applied during a live Telegram gateway setup (July 2026, Windows).

---

## Error: `ValueError: Invalid environment variable name: 'PLATFORMS.TELEGRAM.EXTRA.BOT_TOKEN'`

**Cause:** `hermes config set platforms.telegram.extra.bot_token "..."` treats the dotted key as an env var name (invalid).

**Fix:** Use `.env` for secrets, or edit `config.yaml` directly with Python/yaml.

---

## Error: `No bot token configured` — but token is in `.env`

**Cause 1:** `.env` saved as UTF-16 (PowerShell `>>` default). Hermes reads UTF-8 only.

**Fix:** Rewrite `.env` as UTF-8:
```bash
cat > ~/.hermes/.env << 'EOF'
TELEGRAM_BOT_TOKEN="8863778824:REAL_TOKEN"
TELEGRAM_CHAT_ID="8336840601"
TELEGRAM_ALLOWED_USERS="8336840601"
OBSIDIAN_VAULT_PATH="E:/_Knowledge/ObsidianVault"
EOF
```

**Cause 2:** `config.yaml` has **two** `platforms:` sections (legacy + new). The first one wins and has masked token `bot_token: 8863778824:***`.

**Fix:** Search for all `bot_token:` occurrences and fix **both**:
```bash
grep -n "bot_token" ~/.hermes/config.yaml
# Fix each occurrence
python3 -c "
import re
with open('~/.hermes/config.yaml') as f: c = f.read()
c = re.sub(r'bot_token: \d+:\*\*\*', 'bot_token: \"YOUR_REAL_TOKEN\"', c)
with open('~/.hermes/config.yaml', 'w') as f: f.write(c)
"
```

---

## Error: `Another gateway instance is already running (PID XXXX)`

**Cause:** Gateway started in background or previous terminal.

**Fix:**
```bash
# Windows
taskkill /F /PID XXXX
# Or use --replace flag
hermes gateway run --replace
```

---

## Error: `Refusing to restart the gateway from inside the gateway process`

**Cause:** Running `hermes gateway restart` or `stop` from a shell spawned BY the gateway (SIGTERM propagates).

**Fix:** Stop with `Ctrl+C` in the gateway's own terminal, then rerun from a fresh shell.

---

## Windows `.env` Encoding Fix

PowerShell `echo '...' >> file` writes **UTF-16 LE with BOM**. Hermes's dotenv parser reads UTF-8.

**Always use:**
```bash
# Bash (Git Bash / WSL)
cat > ~/.hermes/.env << 'EOF'
TELEGRAM_BOT_TOKEN="..."
EOF

# Or Python
python3 -c "
with open('~/.hermes/.env', 'w') as f:
    f.write('TELEGRAM_BOT_TOKEN=\"...\"\n')
"
```

---

## Allowlist Not Working

**Symptom:** Bot ignores commands, logs "deny unknown sender"

**Fix:** Set **both** (belt + suspenders):
- `.env`: `TELEGRAM_ALLOWED_USERS="8336840601"`
- `config.yaml`: `admin_chat_ids: '["8336840601"]'` and `dm_policy: open`

---

## Additional Fixes (Session 2)

### Masked Token in config.yaml (Literal `***`)

**Cause:** After failed `hermes config set`, the config shows `bot_token: 8863778824:***` literally. The `***` is not a redaction — it's the stored value.

**Fix:** Direct YAML edit (Python):
```python
import yaml
with open('~/.hermes/config.yaml') as f:
    cfg = yaml.safe_load(f)
cfg['platforms']['telegram']['extra']['bot_token'] = 'REAL_TOKEN'
with open('~/.hermes/config.yaml', 'w') as f:
    yaml.dump(cfg, f)
```

---

### Duplicate `platforms:` Sections

**Symptom:** `grep "bot_token"` shows multiple lines, fixing one doesn't work.

**Fix:** Remove the legacy `platforms:` block (around line 345) or ensure both have correct token.

---

### PowerShell `.env` Encoding (UTF-16)

**Symptom:** `.env` looks correct but `cat` shows `��T\u0000E\u0000L...`

**Fix:** Rewrite with Python or bash heredoc (see above).

---

## Verification Commands

```bash
# Check gateway health
curl http://localhost:8644/health

# Check logs
tail -f ~/.hermes/logs/gateway.log | grep -i telegram

# Test from Telegram
/platforms
/tools
/search "test" in wiki
```