---
name: kb-healthcheck
description: Weekly knowledge base health check - finds conflicts, missing pages, duplicates, unsourced claims, and suggests new articles
version: 1.0.0
category: knowledge-management
tags: [obsidian, knowledge-base, maintenance, karpathy-method, cron]
---

# kb-healthcheck Skill

Periodic knowledge base integrity check. Scans wiki/ for inconsistencies, gaps, duplicates, and quality issues. Produces a health report and optional auto-fix suggestions.

## Usage

```
/kb-healthcheck
/kb-healthcheck --auto-fix
/kb-healthcheck --report-only
```

## Health Checks Performed

### 1. Conflicting Statements
- Scan all concept pages for contradictory claims about the same concept
- Flag numerically inconsistent claims (e.g., "GPT-4 has 1.7T params" vs "GPT-4 has 1.8T params")
- Report confidence-weighted conflicts

### 2. Orphaned Entities (Missing Pages)
- Find entities/concepts mentioned ≥3 times across wiki but lacking dedicated page
- Suggest new concept/entity pages to create

### 3. Near-Duplicate Pages
- Detect concept pages with >80% content similarity (cosine similarity on embeddings or n-gram overlap)
- Suggest merges with diff preview

### 4. Unsourced/Low-Confidence Claims
- Flag claims with confidence <0.6 or missing source references
- Flag pages with no sources listed in frontmatter

### 5. Stale Content
- Pages not updated in >90 days with high-traffic topics
- Sources in 0-raw/ newer than wiki page last_updated

### 6. Graph Connectivity Issues
- Isolated nodes (no backlinks, no forward links)
- Concepts with no related concepts
- Circular reference chains >3 hops

### 7. New Article Candidates
- Emerging connection patterns (concepts frequently co-mentioned but not linked)
- Trending entities in raw/ sources not yet in wiki/

## Output Report

```markdown
---
healthcheck_date: "2026-07-12"
wiki_size:
  concepts: 142
  entities: 87
  index_pages: 12
  raw_sources: 340
issues_found:
  conflicts: 3
  missing_pages: 12
  duplicates: 2
  unsourced_claims: 8
  stale_pages: 5
  isolated_nodes: 7
  new_candidates: 4
---

# Knowledge Base Health Check - 2026-07-12

## Summary
Overall health: 78/100 (Good)

## Critical Issues (Fix First)
### Conflicting Claims
1. **GPT-4 Parameters**: [[GPT-4]] claims 1.7T params (0-raw/gpt4-tech-report.md) but [[LLM-Architectures]] claims 1.8T (0-raw/llama3-paper.md)
   - Recommendation: Verify primary source, update lower-confidence page

### Unsourced High-Stakes Claims
1. [[Prediction-Market-Arbitrage]] claims "80% win rate" with confidence 0.4, no source cited

## Missing Pages (Mentioned ≥3x, No Page)
1. **RLHF** - mentioned in [[RL]], [[LLM-Training]], [[Alignment]]
2. **Constitutional AI** - mentioned in [[Alignment]], [[Claude]], [[Anthropic]]

## Near-Duplicates
1. [[RAG-Architecture]] (85% similar to [[Retrieval-Augmented-Generation]])
   - Suggestion: Merge into [[RAG]] index page, archive one

## Stale Pages (>90 days, high-traffic topics)
1. [[LLM-Benchmarks]] - last updated 2026-03-15, new benchmarks in 0-raw/

## Isolated Nodes
1. [[Obscure-Paper-2023]] - no backlinks, no forward links
2. [[Random-Concept]] - only linked from 0-raw/temp.md

## New Article Candidates
1. **Inference-Time Compute Scaling** - emerging in 5+ recent raw sources, connects [[LLM-Inference]], [[Test-Time-Compute]], [[Reasoning-Models]]
2. **Agent Evaluation Frameworks** - mentioned across [[Agents]], [[Benchmarks]], [[Tool-Use]]

## Auto-Fix Suggestions (--auto-fix)
- Merge [[RAG-Architecture]] → [[Retrieval-Augmented-Generation]]
- Create stub pages for RLHF, Constitutional AI
- Add missing source references to [[Prediction-Market-Arbitrage]]
```

## Implementation Notes

- Use embeddings (sentence-transformers) or n-gram Jaccard for duplicate detection
- Confidence scoring: pages with >5 sources and >3 backlinks = high trust
- Run weekly via cron job
- Output to `reports/healthcheck-YYYY-MM-DD.md`
- Auto-fix only for safe operations (merge duplicates, create stubs)
- Flag conflicts and unsourced claims for human review