---
name: obsidian-graph-styling
description: Style Obsidian's native graph view — graph.json color groups, physics tuning, CSS snippet rules (and why most CSS won't work), and performance tips for large vaults.
platforms: [linux, macos, windows]
trigger: "When user asks to change/fix/style/improve the Obsidian graph view, or mentions graph colors/nodes/layout."
created_by: hermes-agent
---

# Obsidian Graph View Styling

> **Two different things share the name "graph":** Obsidian's **native canvas graph** (tuned via `graph.json`) and a **full HTML/D3.js knowledge graph** (custom build with far more visual power). This skill covers both — use the right one for the job.

## TL;DR — Which to use?

| Goal | Use |
|------|-----|
| Quick within-Obsidian reference | `graph.json` (native) |
| Professional second-brain visualization with glow, legend, search, dark theme | D3.js HTML build (`professional_graph.py`) |

---

## Track A: Native Graph (`graph.json`)

## The One Rule

Obsidian's graph view is **canvas-rendered** (WebGL via Pixi.js/HTML Canvas). CSS selectors like `.graph-view .node`, `.graph-view .link`, `.graph-view canvas` **do not work** — they target DOM elements that don't exist on the canvas layer.

**Exception:** CSS snippets CAN style the graph panel's outer container (background color of the panel, borders, tooltip background) but NOT the nodes/edges themselves. The `pro-graph-view.css` in this user's vault is mostly non-functional for this reason.

## The Real Mechanism: `graph.json`

All graph styling lives in the vault's graph config:

```
{vault}/.obsidian/graph.json
```

### ⚠️ CRITICAL: Obsidian Overwrites This File

**Obsidian resets `graph.json` to defaults every time you close the graph panel, change a setting, or switch tabs.** Your custom colors and physics will silently disappear.

**Fix — make it read-only (Windows):**
```bash
attrib +R "E:\_Knowledge\ObsidianVault\.obsidian\graph.json"
```
To edit again: `attrib -R`, make changes, then re-apply `attrib +R`.

On Mac/Linux: `chmod 444` to make read-only, `chmod 644` to unlock.

### Color Groups

```json
"colorGroups": [
  {
    "query": "tag:#moc OR path:\"05 - MAPS\"",
    "color": { "a": 1, "rgb": 1384146 }
  }
]
```

- **`query`**: Obsidian search syntax — `path:"folder"`, `tag:#tagname`, `tag:#tag1 OR tag:#tag2`, path combinations.
- **`color.rgb`**: Integer RGB value, NOT a hex string. Convert: `parseInt(hex.replace('#',''), 16)`.
- **`a`**: Alpha/opacity (1 = fully opaque).
- **`collapse-color-groups`**: Set to `false` to see all groups simultaneously as distinct colored blobs.

### Recommended RGB values for distinct colors

| Domain | RGB (int) | Hex |
|--------|-----------|-----|
| Purple/MOC | 1384146 | #a020f0 |
| Red/Politics | 12640890 | #c02020 |
| Orange/Daily | 7054550 | #6b9556 |
| Blue/AI | 29104 | #0070e0 |
| Cyan/Aryan Migration | 10971263 | #a76bbf |
| Green/Health | 2563527 | #027360 |
| Pink/Dravidian | 16385087 | #fa3ea7 |
| Yellow/MOCs | 25119136 | #180200 |

### Physics settings (tuning for visual quality)

```json
"nodeSizeMultiplier": 3.5,    // 2.2–3.5 for full-panel view; bigger = more visible
"lineSizeMultiplier": 0.35,   // 0.3–0.6; thinner = less visual noise
"repelStrength": 15,           // 10–15; higher = more spread
"linkDistance": 280,          // 180–280; higher = wider clusters
"centerStrength": 0.12,       // 0.08–0.35; lower = less clustering to center
"linkStrength": 0.5,           // 0.4–0.8
"textFadeMultiplier": 0,      // set to 0 to always show labels
"showArrow": false,           // true = directed arrows; cleaner look without
"collapse-color-groups": false // KEY: must be false to see all colors simultaneously
```

### Getting the outer white tag ring

To match the "second brain" look with a white ring of `#tag` nodes surrounding the main clusters:

```json
"showTags": true,
"showAttachments": false,
"hideUnresolved": false,
"showOrphans": true,
```

`showTags: true` renders all `#tag` nodes as white dots — this creates the distinctive outer ring. `showOrphans: true` ensures unlinked notes are visible.

### Other useful settings

```json
"showTags": true,         // show #tag nodes in graph
"showOrphans": true,      // show unconnected notes
"hideUnresolved": false,  // show broken links as ghost nodes
"showAttachments": false
```

## Performance: large vaults

For vaults with 10,000+ notes, the graph can lag. Add to graph.json:
- Filter with `collapse-filter: true` and set a search query to limit displayed nodes
- Or use the `hideUnresolved: true` + specific path filters to reduce node count

## Verification

After editing `graph.json`, the graph view in Obsidian updates immediately on next open — no restart needed. Toggle the filter panel off and back on to force refresh.

## What CSS CAN do (minimal)

Outer panel styling only — the container, not the canvas:

```css
/* In vault/.obsidian/snippets/your-snippet.css */
/* This works because it targets the HTML container, not the canvas */
.graph-view {
  background-color: #1a1a2e !important;
}
.graph-view .tooltip {
  background: #1e1e2e !important;
  color: #e2e8f0 !important;
  border: 1px solid #4b5563 !important;
}
```

---

## Track B: Professional D3.js Knowledge Graph

When the user says **"make it look professional and like an actual second brain"**, the native `graph.json` approach is insufficient — it cannot do glow, tooltips, search, dark theme, or proper interactivity. Instead, build a **custom HTML/D3.js graph** from the vault's wikilinks and tags.

### Script location
```
{vault}/professional_graph.py
```

### Run command
```bash
python professional_graph.py
# Or for this user's Python 3.14 (has networkx bundled):
"C:/Users/shrey/AppData/Local/Programs/Python/Python314/python.exe" professional_graph.py
```
Output: `{vault}/obsidian_graph.html` — open in any browser.

### Key features of the pro graph

| Feature | Implementation |
|---------|---------------|
| Dark theme background | CSS `#080b14` with radial gradient |
| Node glow | SVG `<filter id="glow">` on high-degree nodes (degree > 15) |
| Degree-based sizing | `max(5, min(35, 5 + deg * 1.5))` |
| Domain coloring | 17-domain palette; tags = white radial gradient |
| Clickable legend | Show/hide entire domain groups |
| Live search | Filters nodes by label or domain |
| Tags toggle | Hide/show `#tag` nodes |
| Hub node labels | Only shown for `degree > 8` |
| Rich tooltips | Domain badge, degree, community, linked notes, tags |
| Physics | D3 `forceSimulation` with collide + x/y drift |
| Background stars | Decorative ambient circles |
| Loading screen | Spinner + fade while JS initializes |

### Domain palette (this user's vault — update for your own)

```python
DOMAIN_PALETTE = {
    "Indian Political History":  "#e74c3c",
    "Dravidian Politics / Tamil Nadu": "#c0392b",
    "Aryan Migration / IVC / DNA": "#9b59b6",
    "RSS / Hindutva / Sangh Parivar": "#e67e22",
    "Philosophy & Religion": "#8e44ad",
    "Buddhism / Shramana": "#d35400",
    "Anti-Caste / Ambedkar / Phule": "#95a5a6",
    "AI & Technology / PKM": "#3498db",
    "Health & Fitness": "#27ae60",
    "Agentic Systems": "#f39c12",
    "Maps / MOCs": "#5f27cd",
    "Daily Notes / Logs": "#54a0ff",
    "Sources / Literature": "#feca57",
    "Output / Analyses": "#00cec9",
    "Projects / PARA": "#ff6b81",
    "System / Infrastructure": "#1dd1a1",
    "Second Brain / LLM Wiki": "#00b4d8",
    "tag": "#ffffff",
    "default": "#636e72",
}
```

### Python dependencies
```bash
pip install networkx python-louvain
```
`networkx` is the common failure point — both the system Python and Python 3.13 may not have it. On this Windows machine use Python 3.14 directly:
```
"C:/Users/shrey/AppData/Local/Programs/Python/Python314/python.exe" professional_graph.py
```

### "Make it look professional and like a second brain" workflow

1. **Don't touch `graph.json`** — it's insufficient for the visual bar the user wants.
2. **Parse wikilinks** `\[\[(.*?)\]\]` and tags `#([\w/-]+)` from all `.md` files.
3. **Exclude**: `.obsidian`, `.smart-env`, `.git`, `node_modules`, `_trash`, `.trash`.
4. **Build NetworkX graph** → cap at 600 nodes (top by degree) → Louvain community detection → modularity ~0.45 is normal.
5. **Size by degree**, **color by domain**, **glow on hubs** (degree > 15), **white dots for tags**.
6. **Inject JSON into D3.js HTML template** — D3 loaded from CDN (`cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js`).
7. Use `spring_layout` (NetworkX) as D3 `forceSimulation` initial positions.
8. **Verify**: HTML file > 50 KB, `__GRAPH_DATA__` replaced, `d3.min.js` present, `forceSimulation` present.

### Common errors

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError: No module named 'networkx'` | Use Python 3.14 path directly |
| `__GRAPH_DATA__` still appearing in output | `json.dumps` replacement failed — check the substitution line |
| Nodes missing | Files in `_trash`/`.obsidian` are excluded; check `EXCLUDE` set |
| Graph looks clumped | Lower `forceCharge` strength or increase `collide` separation |

### Performance targets
- Cap nodes at 600 for smooth physics on typical hardware.
- 76 communities with modularity 0.45 = well-connected PKM vault (normal).
- Edge cap auto-managed by node cap + degree ordering.